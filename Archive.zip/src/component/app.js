import {createElement} from 'react';
import Cart from './cart';
import Products from './products';

export default () => (
  <div>
    <Cart/>
    <Products/>
  </div>
);
