export const cake = {
  id: 'cake',
  title: 'Cake',
  image: 'http://i.imgur.com/Syl84O4.jpg',
  price: 2.44,
};

export const waffle = {
  id: 'waffle',
  title: 'Waffle',
  image: 'http://i.imgur.com/jyS1LHA.png',
  price: 5.23,
};

export const chocolate = {
  id: 'chocolate',
  title: 'Chocolate',
  image: 'http://i.imgur.com/SX6fy96.jpg',
  price: 3.32,
};
