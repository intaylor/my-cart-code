export const CLEAR_ITEMS = 'CLEAR_ITEMS';
export const ADD_ITEM = 'ADD_ITEM';
export const SET_QUANTITY = 'SET_QUANTITY';
